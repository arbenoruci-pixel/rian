"use client";

import React, { useEffect, useMemo, useState } from "react";
import Link from "@/lib/routerCompat.jsx";
import { supabase } from "@/lib/supabaseClient";
import { buildMonthlyPayrollPreview, getCurrentPayrollMonth, getMonthWindow } from "@/lib/payrollMonthClose";

const RESERVE_AMOUNT = 1000;
const OWNER_REPAYMENT_PERCENT = 30;
const PROFIT_SPLIT_PERCENT = 70;
const OWNER_PROFIT_SHARE = 50;
const DB_TIMEOUT_MS = 4500;
const OPEN_CASH_STATUSES = ["PENDING", "COLLECTED"];
const OPEN_CASH_EXCLUDED_TYPES = new Set([
  "EXPENSE",
  "TIMA",
  "MEAL_PAYMENT",
  "MEAL_COVERED",
  "ADVANCE",
  "SALARY_PAYMENT",
]);

function n(value) {
  const parsed = Number(value || 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function upper(value) {
  return String(value || "").trim().toUpperCase();
}

function money(value) {
  return `€${n(value).toLocaleString("de-DE", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function fmtDateTime(value) {
  if (!value) return "—";
  try {
    return new Date(value).toLocaleString("sq-AL", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  } catch {
    return "—";
  }
}

function compactError(error) {
  const msg = String(error?.message || error?.details || error?.hint || error || "").trim();
  if (!msg) return "Nuk u lexua";
  if (msg.length > 120) return `${msg.slice(0, 120)}...`;
  return msg;
}

function withTimeout(promise, ms = DB_TIMEOUT_MS, label = "Kërkesa mori shumë kohë") {
  let timer = null;
  return Promise.race([
    Promise.resolve(promise),
    new Promise((_, reject) => {
      timer = window.setTimeout(() => reject(new Error(label)), ms);
    }),
  ]).finally(() => {
    try {
      if (timer) window.clearTimeout(timer);
    } catch {}
  });
}

function startOfCurrentMonthIso() {
  const d = new Date();
  return new Date(d.getFullYear(), d.getMonth(), 1, 0, 0, 0).toISOString();
}

function isOpenCashRow(row) {
  const status = upper(row?.status);
  const type = upper(row?.type);
  if (!OPEN_CASH_STATUSES.includes(status)) return false;
  if (OPEN_CASH_EXCLUDED_TYPES.has(type)) return false;
  return true;
}

function ownerBucket(entries = [], ownerId, entryType) {
  return entries
    .filter((entry) => String(entry?.owner_id) === String(ownerId))
    .filter((entry) => upper(entry?.status || "ACTIVE") === "ACTIVE")
    .filter((entry) => upper(entry?.entry_type) === entryType)
    .reduce((sum, entry) => sum + n(entry?.remaining_amount), 0);
}

function ownerTotal(entries = [], ownerId) {
  return entries
    .filter((entry) => String(entry?.owner_id) === String(ownerId))
    .filter((entry) => upper(entry?.status || "ACTIVE") === "ACTIVE")
    .reduce((sum, entry) => sum + n(entry?.remaining_amount), 0);
}

function sourceLabel(row) {
  const src = String(row?.source_type || row?.source || "").trim();
  const id = row?.source_id || row?.sourceId || "";
  if (src && id) return `${src} #${id}`;
  return src || (id ? `#${id}` : "—");
}

function ledgerDescription(row) {
  return String(row?.description || row?.note || row?.memo || row?.category || "—").trim() || "—";
}

function normalizeRpcArray(value) {
  return Array.isArray(value) ? value : [];
}

function normalizeRpcObject(value) {
  return value && typeof value === "object" && !Array.isArray(value) ? value : null;
}

async function readKapakuPreview({ startIso, endIso }) {
  const res = await withTimeout(
    supabase.rpc("get_arka_kapaku_preview", {
      p_month_start: startIso,
      p_month_end: endIso,
    }),
    DB_TIMEOUT_MS,
    "Kapaku preview: Nuk u lexua"
  );
  if (res?.error) throw res.error;
  return res?.data || {};
}

function MiniStat({ label, value, tone = "neutral", sub = "" }) {
  return (
    <div className={`arkaMiniStat ${tone}`}>
      <div className="arkaMiniStatLabel">{label}</div>
      <div className="arkaMiniStatValue">{value}</div>
      {sub ? <div className="arkaMiniStatSub">{sub}</div> : null}
    </div>
  );
}

function RowLine({ label, value, strong = false, tone = "" }) {
  return (
    <div style={styles.rowLine}>
      <span style={styles.rowLabel}>{label}</span>
      <strong style={{ ...styles.rowValue, ...(strong ? styles.rowValueStrong : null), ...(tone === "bad" ? styles.badText : null), ...(tone === "ok" ? styles.okText : null) }}>{value}</strong>
    </div>
  );
}

function ReadError({ label, error }) {
  if (!error) return null;
  return (
    <div style={styles.errorBox}>
      {label}: {error || "Nuk u lexua"}
    </div>
  );
}

function KapakuPage() {
  const [loading, setLoading] = useState(true);
  const [state, setState] = useState({
    summary: null,
    ledger: [],
    owners: [],
    ownerEntries: [],
    fixedExpenses: [],
    users: [],
    monthPayments: [],
    openPayments: [],
    handoffs: [],
    errors: {},
  });

  async function reload() {
    setLoading(true);
    const month = getCurrentPayrollMonth();
    const { startIso, endIso } = getMonthWindow(month);

    try {
      const data = await readKapakuPreview({ startIso, endIso });
      setState({
        summary: normalizeRpcObject(data?.summary),
        ledger: normalizeRpcArray(data?.ledger),
        owners: normalizeRpcArray(data?.owners),
        ownerEntries: normalizeRpcArray(data?.ownerEntries),
        fixedExpenses: normalizeRpcArray(data?.fixedExpenses),
        users: normalizeRpcArray(data?.users),
        monthPayments: normalizeRpcArray(data?.monthPayments),
        openPayments: normalizeRpcArray(data?.openPayments),
        handoffs: normalizeRpcArray(data?.handoffs),
        errors: {},
      });
    } catch (error) {
      setState({
        summary: null,
        ledger: [],
        owners: [],
        ownerEntries: [],
        fixedExpenses: [],
        users: [],
        monthPayments: [],
        openPayments: [],
        handoffs: [],
        errors: {
          preview: compactError(error) || "Nuk u lexua",
          owners: "Nuk u lexua",
          ownerEntries: "Nuk u lexua",
        },
      });
    }

    setLoading(false);
  }

  useEffect(() => {
    let alive = true;
    const t = window.setTimeout(() => {
      if (alive) void reload();
    }, 80);
    return () => {
      alive = false;
      window.clearTimeout(t);
    };
  }, []);

  const computed = useMemo(() => {
    const companyCash = n(state.summary?.current_balance);
    const totalIn = n(state.summary?.total_in);
    const totalOut = n(state.summary?.total_out);

    const activeOwners = (state.owners || []).filter((owner) => owner?.is_active !== false);
    const ownerCards = activeOwners.map((owner) => ({
      ...owner,
      totalRemaining: ownerTotal(state.ownerEntries, owner?.id),
      shortTermRemaining: ownerBucket(state.ownerEntries, owner?.id, "LOAN_SHORT_TERM"),
      longTermRemaining: ownerBucket(state.ownerEntries, owner?.id, "CAPITAL_LONG_TERM"),
    }));
    const totalOwnerBalance = ownerCards.reduce((sum, owner) => sum + n(owner.totalRemaining), 0);

    const fixedRows = (state.fixedExpenses || []).filter((row) => row && row.active !== false);
    const essentialObligations = fixedRows
      .filter((row) => row?.essential !== false)
      .reduce((sum, row) => sum + n(row?.amount), 0);

    const payrollRows = buildMonthlyPayrollPreview({
      workers: state.users || [],
      paymentRows: state.monthPayments || [],
      month: getCurrentPayrollMonth(),
    });
    const payrollNet = payrollRows.reduce((sum, row) => sum + n(row?.net), 0);

    const openCashRows = (state.openPayments || []).filter(isOpenCashRow);
    const masterCashRows = openCashRows.filter((row) => String(row?.created_by_pin || "").trim() === "2380");
    const workerCashRows = openCashRows.filter((row) => String(row?.created_by_pin || "").trim() !== "2380");
    const masterCash = masterCashRows.reduce((sum, row) => sum + n(row?.amount), 0);
    const workerCash = workerCashRows.reduce((sum, row) => sum + n(row?.amount), 0);
    const openCashBlockers = masterCash + workerCash;

    const pendingDispatch = (state.handoffs || []).reduce((sum, row) => sum + n(row?.amount || row?.total_amount), 0);

    const distributableProfit = +(
      companyCash
      - RESERVE_AMOUNT
      - essentialObligations
      - payrollNet
      - openCashBlockers
      - pendingDispatch
    ).toFixed(2);

    const positiveProfit = Math.max(0, distributableProfit);
    const ownerRepaymentPool = +(positiveProfit * (OWNER_REPAYMENT_PERCENT / 100)).toFixed(2);
    const profitSplitPool = +(positiveProfit - ownerRepaymentPool).toFixed(2);
    const arbenProfit = +(profitSplitPool * (OWNER_PROFIT_SHARE / 100)).toFixed(2);
    const fitimProfit = +(profitSplitPool * (OWNER_PROFIT_SHARE / 100)).toFixed(2);

    return {
      companyCash,
      totalIn,
      totalOut,
      ownerCards,
      totalOwnerBalance,
      essentialObligations,
      payrollRows,
      payrollNet,
      workerCash,
      masterCash,
      openCashBlockers,
      pendingDispatch,
      distributableProfit,
      ownerRepaymentPool,
      profitSplitPool,
      arbenProfit,
      fitimProfit,
    };
  }, [state]);

  return (
    <div className="arkaSimplePage">
      <div className="arkaSimpleTop">
        <div>
          <div className="arkaSimpleEyebrow">KAPAKU I ARKËS</div>
          <h1 className="arkaSimpleTitle">KAPAKU I ARKËS</h1>
          <div className="arkaSimpleSub">READ-ONLY PREVIEW • PA POSTIM • PA LEDGER • PA NDRYSHIME</div>
        </div>
        <div className="arkaSimpleNav">
          <button className="arkaTopBtn" type="button" onClick={reload} disabled={loading}>{loading ? "DUKE LEXUAR" : "RIFRESKO"}</button>
          <Link className="arkaTopBtn" to="/arka">ARKA</Link>
        </div>
      </div>

      {loading ? <div className="arkaLoaderCard">DUKE LEXUAR KAPAKUN E ARKËS...</div> : null}
      <ReadError label="Kapaku preview RPC" error={state.errors.preview} />

      <section className="arkaHeroSingle arkaHeroMainDue">
        <div>
          <div className="arkaSectionTitle">BUXHETI AKTUAL</div>
          <div className="arkaSectionSub">COMPANY_BUDGET_SUMMARY ID=1</div>
        </div>
        <div className="arkaHeroDueHuge">{money(computed.companyCash)}</div>
      </section>

      <section className="arkaSectionCard">
        <div className="arkaSectionHeadCompact">
          <div>
            <div className="arkaSectionTitle">BUXHETI AKTUAL</div>
            <div className="arkaSectionSub">Cash në kompani / hyrje / dalje</div>
          </div>
        </div>
        <div className="arkaOwnerFormulaGrid compactStats">
          <MiniStat label="Cash në kompani" value={money(computed.companyCash)} tone="ok" />
          <MiniStat label="Total hyrje" value={money(computed.totalIn)} tone="info" />
          <MiniStat label="Total dalje" value={money(computed.totalOut)} tone="warn" />
          <MiniStat label="Përditësuar" value={fmtDateTime(state.summary?.updated_at)} tone="muted" />
        </div>
        <ReadError label="Buxheti aktual" error={state.errors.summary} />
      </section>

      <section className="arkaSectionCard">
        <div className="arkaSectionHeadCompact">
          <div>
            <div className="arkaSectionTitle">BORXHET NDAJ PRONARËVE</div>
            <div className="arkaSectionSub">Owner capital / loans • historical balance only</div>
          </div>
          <div className="arkaCashTotalPill">TOTAL {money(computed.totalOwnerBalance)}</div>
        </div>

        <div className="arkaSplitGrid detailPage">
          {computed.ownerCards.length ? computed.ownerCards.map((owner) => (
            <div key={owner.id || owner.owner_key} className="arkaWorkerCard">
              <div className="arkaWorkerTop">
                <div>
                  <div className="arkaWorkerName">{owner.display_name || owner.owner_key}</div>
                  <div className="arkaWorkerMeta">{owner.owner_key} • PROFIT {n(owner.profit_share_percent).toFixed(0)}%</div>
                </div>
                <div className="arkaCashTotalPill">{money(owner.totalRemaining)}</div>
              </div>
              <div style={styles.cleanBox}>
                <RowLine label="Short-term loan" value={money(owner.shortTermRemaining)} />
                <RowLine label="Long-term capital" value={money(owner.longTermRemaining)} />
                <RowLine label="Total remaining" value={money(owner.totalRemaining)} strong />
              </div>
            </div>
          )) : (
            <div className="arkaEmpty">Nuk u lexuan pronarët ose nuk ka rreshta.</div>
          )}
        </div>
        <ReadError label="Owner accounts" error={state.errors.owners} />
        <ReadError label="Owner capital entries" error={state.errors.ownerEntries} />
      </section>

      <section className="arkaSectionCard">
        <div className="arkaSectionHeadCompact">
          <div>
            <div className="arkaSectionTitle">OBLIGIME / PAYROLL / BLOCKERS</div>
            <div className="arkaSectionSub">Read-only preview për waterfall</div>
          </div>
        </div>
        <div className="arkaOwnerFormulaGrid compactStats">
          <MiniStat label="Obligime essential" value={money(computed.essentialObligations)} tone="warn" />
          <MiniStat label="Payroll net preview" value={money(computed.payrollNet)} tone="warn" />
          <MiniStat label="Cash workers hapur" value={money(computed.workerCash)} tone={computed.workerCash > 0 ? "warn" : "ok"} />
          <MiniStat label="Master cash hapur" value={money(computed.masterCash)} tone={computed.masterCash > 0 ? "warn" : "ok"} />
          <MiniStat label="Pending dispatch" value={money(computed.pendingDispatch)} tone={computed.pendingDispatch > 0 ? "warn" : "ok"} />
        </div>
        <ReadError label="Obligime" error={state.errors.fixedExpenses} />
        <ReadError label="Payroll users" error={state.errors.users} />
        <ReadError label="Payroll payments" error={state.errors.monthPayments} />
        <ReadError label="Cash i hapur" error={state.errors.openPayments} />
        <ReadError label="Pending dispatch" error={state.errors.handoffs} />
      </section>

      <section className="arkaSectionCard ownerFormulaBox">
        <div className="arkaSectionHeadCompact">
          <div>
            <div className="arkaSectionTitle">WATERFALL</div>
            <div className="arkaSectionSub">Preview only • nuk krijon distribution</div>
          </div>
          <div className="arkaCashTotalPill">{computed.distributableProfit > 0 ? "KA PROFIT" : "NUK KA PROFIT"}</div>
        </div>

        <div style={styles.cleanBox}>
          <RowLine label="Cash available" value={money(computed.companyCash)} strong />
          <RowLine label="- Reserve" value={money(RESERVE_AMOUNT)} />
          <RowLine label="- Obligime essential" value={money(computed.essentialObligations)} />
          <RowLine label="- Payroll net" value={money(computed.payrollNet)} />
          <RowLine label="- Cash blockers" value={money(computed.openCashBlockers)} />
          <RowLine label="- Pending dispatch" value={money(computed.pendingDispatch)} />
          <RowLine
            label="= Profit i disponueshëm"
            value={money(computed.distributableProfit)}
            strong
            tone={computed.distributableProfit > 0 ? "ok" : "bad"}
          />
        </div>

        {computed.distributableProfit <= 0 ? (
          <div style={styles.blockedBox}>NUK KA PROFIT TË DISPONUESHËM</div>
        ) : (
          <div className="arkaOwnerFormulaGrid compactStats" style={{ marginTop: 12 }}>
            <MiniStat label="Kthim borxhi 30%" value={money(computed.ownerRepaymentPool)} tone="info" />
            <MiniStat label="Profit split 70%" value={money(computed.profitSplitPool)} tone="ok" />
            <MiniStat label="Arben 50%" value={money(computed.arbenProfit)} tone="strong" />
            <MiniStat label="Fitim 50%" value={money(computed.fitimProfit)} tone="strong" />
          </div>
        )}
      </section>

      <section className="arkaSectionCard">
        <div className="arkaSectionHeadCompact">
          <div>
            <div className="arkaSectionTitle">PROFIT PREVIEW</div>
            <div className="arkaSectionSub">Default: reserve {money(RESERVE_AMOUNT)} • repayment {OWNER_REPAYMENT_PERCENT}% • split {PROFIT_SPLIT_PERCENT}%</div>
          </div>
        </div>
        <div style={styles.cleanBox}>
          <RowLine label="Kthim borxhi/investimi" value={`${OWNER_REPAYMENT_PERCENT}% • ${money(computed.ownerRepaymentPool)}`} />
          <RowLine label="Profit split pool" value={`${PROFIT_SPLIT_PERCENT}% • ${money(computed.profitSplitPool)}`} />
          <RowLine label="Arben profit 50%" value={money(computed.arbenProfit)} />
          <RowLine label="Fitim profit 50%" value={money(computed.fitimProfit)} />
        </div>
      </section>

      <section className="arkaSectionCard">
        <div className="arkaSectionHeadCompact">
          <div>
            <div className="arkaSectionTitle">LËVIZJET E FUNDIT</div>
            <div className="arkaSectionSub">20 rreshtat e fundit nga company_budget_ledger</div>
          </div>
        </div>

        {state.ledger.length ? (
          <div className="arkaCashCompactList">
            {state.ledger.map((row) => (
              <div className="arkaCashCompactRow mini" key={row.id || `${row.created_at}_${row.amount}_${row.category}`}>
                <div className="arkaCashCompactSummary" style={{ cursor: "default" }}>
                  <span className="arkaCashCode">{upper(row.direction) || "—"}</span>
                  <span className="arkaCashNameWrap">
                    <span className="arkaCashName">{row.category || "LËVIZJE"}</span>
                    <span className="arkaCashStamp">{fmtDateTime(row.created_at)} • {sourceLabel(row)}</span>
                  </span>
                  <span className="arkaCashAmount">{money(row.amount)}</span>
                </div>
                <div className="arkaCashCompactDetails">
                  <span>{ledgerDescription(row)}</span>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="arkaEmpty">Nuk ka lëvizje të lexuara.</div>
        )}
        <ReadError label="Company budget ledger" error={state.errors.ledger} />
      </section>
    </div>
  );
}

const styles = {
  cleanBox: {
    display: "grid",
    gap: 8,
    padding: 12,
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,.08)",
    background: "rgba(0,0,0,.24)",
  },
  rowLine: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 12,
    minHeight: 32,
    borderBottom: "1px solid rgba(255,255,255,.06)",
  },
  rowLabel: {
    fontSize: 10,
    fontWeight: 900,
    letterSpacing: ".13em",
    textTransform: "uppercase",
    color: "rgba(229,231,235,.62)",
  },
  rowValue: {
    fontSize: 13,
    fontWeight: 1000,
    color: "#fff",
    whiteSpace: "nowrap",
  },
  rowValueStrong: {
    fontSize: 16,
    color: "#dcfce7",
  },
  okText: {
    color: "#86efac",
  },
  badText: {
    color: "#fca5a5",
  },
  blockedBox: {
    marginTop: 12,
    padding: "12px 14px",
    borderRadius: 14,
    border: "1px solid rgba(245,158,11,.32)",
    background: "rgba(245,158,11,.12)",
    color: "#fde68a",
    fontSize: 11,
    fontWeight: 1000,
    letterSpacing: ".14em",
    textTransform: "uppercase",
  },
  errorBox: {
    marginTop: 10,
    padding: "9px 10px",
    borderRadius: 12,
    border: "1px solid rgba(245,158,11,.25)",
    background: "rgba(245,158,11,.08)",
    color: "#fde68a",
    fontSize: 10,
    fontWeight: 900,
    letterSpacing: ".08em",
    textTransform: "uppercase",
  },
};

export default KapakuPage;
